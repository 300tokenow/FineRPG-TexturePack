#version 330
#moj_import <finerpg_gui.glsl>

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
    float LineWidth;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec2 UV0;
in vec4 Color;
uniform sampler2D Sampler0;
out vec2 texCoord0;
out vec4 vertexColor;

void main() {
    FineGuiData data = finerpgGui(ProjMat, Sampler0, Position, UV0);
    texCoord0 = data.uv0;
    vertexColor = Color;
    gl_Position = ProjMat * ModelViewMat * vec4(data.position, 1.0);
}
