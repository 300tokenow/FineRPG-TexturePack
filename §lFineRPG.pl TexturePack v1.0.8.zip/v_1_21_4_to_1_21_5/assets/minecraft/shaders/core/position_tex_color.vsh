#version 150
#moj_import <finerpg_gui.glsl>

in vec3 Position;
in vec2 UV0;
in vec4 Color;

uniform sampler2D Sampler0;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec2 texCoord0;
out vec4 vertexColor;

void main() {
    FineGuiData data = finerpgGui(ProjMat, Sampler0, Position, UV0);
    texCoord0 = data.uv0;
    vertexColor = Color;
    gl_Position = ProjMat * ModelViewMat * vec4(data.position, 1.0);
}
