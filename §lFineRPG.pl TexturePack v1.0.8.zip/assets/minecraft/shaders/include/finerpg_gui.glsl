// FineRPG Custom GUI helper for 1.21.4 -> 26.1
// Marker scheme expected by the FineRPG GUI textures:
// 251,0,0,1 = player inventory
// 250,0,0,1 = generic_54 lower/player-inventory blit
// 249,0,0,1 = generic_54 upper/container blit to suppress

struct FineGuiData {
    vec3 position;
    vec2 uv0;
};

const vec2 FINE_CORNERS[4] = vec2[](
    vec2(0.0, 0.0),
    vec2(0.0, 1.0),
    vec2(1.0, 1.0),
    vec2(1.0, 0.0)
);

bool finePosCheckY(vec3 position, vec2 screen, float offset, float size, vec2 corner) {
    float expected = round(screen.y * 0.5) + offset + size * corner.y;
    return abs(expected - position.y) <= 0.25;
}

int fineGenericRows(vec3 position, vec2 screen, vec2 corner) {
    if (finePosCheckY(position, screen, -31.0, 96.0, corner)) return 0; // 9x1
    if (finePosCheckY(position, screen, -22.0, 96.0, corner)) return 1; // 9x2
    if (finePosCheckY(position, screen, -13.0, 96.0, corner)) return 2; // 9x3
    if (finePosCheckY(position, screen,  -4.0, 96.0, corner)) return 3; // 9x4
    if (finePosCheckY(position, screen,   5.0, 96.0, corner)) return 4; // 9x5
    if (finePosCheckY(position, screen,  14.0, 96.0, corner)) return 5; // 9x6
    return -1;
}

FineGuiData finerpgGui(mat4 projMat, sampler2D sampler0, vec3 position, vec2 uv0) {
    vec3 pos = position;
    int vertId = gl_VertexID % 4;
    vec2 corner = FINE_CORNERS[vertId];

    // Sample just inside the edge so the last vertex still resolves to the marker texel.
    vec4 marker = round(texture(sampler0, uv0 - 0.00001 * corner) * 255.0);
    vec2 screen = 2.0 / vec2(projMat[0][0], -projMat[1][1]);

    // Player inventory: vanilla 176x166 -> custom 320x320.
    if (marker.a == 1.0 && marker.r == 251.0 && marker.g == 0.0 && marker.b == 0.0) {
        pos.xy += ((corner - 0.5) * 2.0) * vec2(72.0, 77.0);
        // FineRPG inventory artwork is expected in x=128..447, y=128..447 of 1024x1024.
        uv0 = (vec2(128.0) + corner * 320.0) / 1024.0;
        return FineGuiData(pos, uv0);
    }

    // generic_54 lower 176x96 blit -> one of six 256x256 GUI slices.
    if (marker.a == 1.0 && marker.r == 250.0 && marker.g == 0.0 && marker.b == 0.0) {
        int rows = fineGenericRows(position, screen, corner);
        if (rows >= 0) {
            if (vertId == 0 || vertId == 3) {
                pos.x += (corner.x - 0.5) * 80.0;
                pos.y -= 128.0;
            } else {
                pos.x += (corner.x - 0.5) * 80.0;
                pos.y += 32.0;
            }

            // FineRPG generic_54 atlas is expected to be 3072x256.
            // x=0..255 reserved, then six 256px slices.
            float startX = 256.0 + float(rows) * 256.0;
            uv0 = vec2((startX + corner.x * 256.0) / 3072.0, corner.y);
            return FineGuiData(pos, uv0);
        }
    }

    // Suppress the vanilla variable-height upper generic container blit.
    if (marker.a == 1.0 && marker.r == 249.0 && marker.g == 0.0 && marker.b == 0.0) {
        pos.xy = vec2(-10000.0, -10000.0);
        return FineGuiData(pos, uv0);
    }

    return FineGuiData(pos, uv0);
}
