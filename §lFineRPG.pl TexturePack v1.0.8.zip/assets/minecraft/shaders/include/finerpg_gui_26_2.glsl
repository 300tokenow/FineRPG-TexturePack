#version 330
#extension GL_ARB_shader_draw_parameters : enable
#extension SPV_KHR_shader_draw_parameters : enable

// FineRPG Custom GUI helper for Minecraft 26.2.
// Kept as a separate root include because 26.2 batches GUI draws with a base vertex.

struct Fine262Data {
    vec3 position;
    vec2 uv0;
};

vec2[] fine262Corners = vec2[](
    vec2(0.0, 0.0),
    vec2(0.0, 1.0),
    vec2(1.0, 1.0),
    vec2(1.0, 0.0)
);

bool fine262PosCheckY(vec3 position, vec2 screen, float offset, float size, vec2 corner) {
    float expected = round(screen.y / 2.0) + offset + size * corner.y;
    return abs(expected - position.y) <= 0.25;
}

int fine262Rows(vec3 position, vec2 screen, vec2 corner) {
    if (fine262PosCheckY(position, screen, -31.0, 96.0, corner)) return 0;
    if (fine262PosCheckY(position, screen, -22.0, 96.0, corner)) return 1;
    if (fine262PosCheckY(position, screen, -13.0, 96.0, corner)) return 2;
    if (fine262PosCheckY(position, screen,  -4.0, 96.0, corner)) return 3;
    if (fine262PosCheckY(position, screen,   5.0, 96.0, corner)) return 4;
    if (fine262PosCheckY(position, screen,  14.0, 96.0, corner)) return 5;
    return -1;
}

Fine262Data finerpgGui262(mat4 ProjMat, float GameTime, sampler2D Sampler0, vec3 Position, vec2 texCoord0) {
    vec3 pos = Position;

    // This is the important 26.2 difference. GUI quads may start at a non-zero base vertex.
    int vertID = (gl_VertexID - gl_BaseVertexARB) % 4;
    if (vertID < 0) vertID += 4;
    vec2 corner = fine262Corners[vertID];

    // Same control-pixel technique as before.
    vec4 marker = round(texture(Sampler0, texCoord0 - (0.00001 * corner)) * 255.0);
    vec2 screen = 2.0 / vec2(ProjMat[0][0], -ProjMat[1][1]);

    // 251,0,0,1 = player inventory.
    if (marker.a == 1.0 && marker.r == 251.0 && marker.g == 0.0 && marker.b == 0.0) {
        pos.xy += ((corner - 0.5) * 2.0) * vec2(72.0, 77.0);
        texCoord0 = (vec2(128.0) + corner * 320.0) / 1024.0;
        return Fine262Data(pos, texCoord0);
    }

    // 250,0,0,1 = lower 176x96 generic_54 blit.
    if (marker.a == 1.0 && marker.r == 250.0 && marker.g == 0.0 && marker.b == 0.0) {
        int rows = fine262Rows(Position, screen, corner);
        if (rows >= 0) {
            if (vertID == 0 || vertID == 3) {
                pos.x += (corner.x - 0.5) * 80.0;
                pos.y -= 128.0;
            } else {
                pos.x += (corner.x - 0.5) * 80.0;
                pos.y += 32.0;
            }

            float startX = 256.0 + float(rows) * 256.0;
            texCoord0 = vec2((startX + corner.x * 256.0) / 3072.0, corner.y);
            return Fine262Data(pos, texCoord0);
        }
    }

    // 249,0,0,1 = suppress upper variable-height generic_54 blit.
    if (marker.a == 1.0 && marker.r == 249.0 && marker.g == 0.0 && marker.b == 0.0) {
        pos.xy = vec2(-10000.0, -10000.0);
        return Fine262Data(pos, texCoord0);
    }

    return Fine262Data(pos, texCoord0);
}
