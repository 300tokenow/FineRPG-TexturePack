#version 150

in vec3 Position;
in vec4 Color;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec4 vertexColor;

bool finerpgIsDim(vec4 c) {
    const float D = 16.0 / 255.0;
    return all(lessThan(abs(c.rgb - vec3(D)), vec3(0.001))) && c.a > 0.45 && c.a < 0.95;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexColor = Color;
    if (finerpgIsDim(vertexColor)) vertexColor.a = 0.0;
}
